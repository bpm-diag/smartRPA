
// when extension is clicked, check if server is running and display messages accordingly
document.addEventListener("DOMContentLoaded", function() {
    checkServerStatus();
});